package com.example.prelim;

import android.app.Activity;

public class MainActivity extends Activity {
}
